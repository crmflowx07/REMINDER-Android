package com.muzamil.reminder.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ReminderEntity::class, ReminderAlertEntity::class, CategoryEntity::class,
        RoutineEntity::class, RoutineItemEntity::class, IdeaEntity::class,
        PlanEntity::class, GoalEntity::class, TripEntity::class, TripPlaceEntity::class,
        CustomSoundEntity::class, CompletedReminderHistoryEntity::class, ProfileEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class ReminderDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile private var INSTANCE: ReminderDatabase? = null
        fun get(context: Context): ReminderDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                ReminderDatabase::class.java,
                "reminder.db"
            ).build().also { INSTANCE = it }
        }
    }
}
