package com.muzamil.reminder.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM reminders WHERE isDeleted = 0 AND isCompleted = 0 ORDER BY triggerAt ASC")
    fun activeReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun reminderById(id: Long): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    fun reminderByIdFlow(id: Long): Flow<ReminderEntity?>

    @Query("SELECT * FROM reminders WHERE isDeleted = 0 AND isCompleted = 0 AND triggerAt BETWEEN :start AND :end ORDER BY triggerAt ASC")
    fun remindersBetween(start: Long, end: Long): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isDeleted = 0 AND isCompleted = 0 AND triggerAt < :now ORDER BY triggerAt DESC")
    fun overdue(now: Long): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isDeleted = 0 AND isCompleted = 1 ORDER BY occurrenceCompletedAt DESC")
    fun completedReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT r.* FROM reminders r LEFT JOIN categories c ON r.categoryId = c.id WHERE r.isDeleted = 0 AND (r.title LIKE '%' || :query || '%' OR r.description LIKE '%' || :query || '%' OR c.name LIKE '%' || :query || '%') ORDER BY r.triggerAt ASC")
    fun searchReminders(query: String): Flow<List<ReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Update suspend fun updateReminder(reminder: ReminderEntity)

    @Query("UPDATE reminders SET isDeleted = 1, updatedAt = :now WHERE id = :id")
    suspend fun softDeleteReminder(id: Long, now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET isCompleted = :completed, occurrenceCompletedAt = :completedAt, updatedAt = :now WHERE id = :id")
    suspend fun setReminderCompleted(id: Long, completed: Boolean, completedAt: Long?, now: Long = System.currentTimeMillis())

    @Query("UPDATE reminders SET triggerAt = :newTriggerAt, isCompleted = 0, occurrenceCompletedAt = NULL, updatedAt = :now WHERE id = :id")
    suspend fun rescheduleReminder(id: Long, newTriggerAt: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM reminder_alerts WHERE reminderId = :reminderId ORDER BY offsetMinutes DESC")
    suspend fun alertsForReminder(reminderId: Long): List<ReminderAlertEntity>

    @Query("SELECT * FROM reminder_alerts WHERE triggerTime >= :now AND isCompleted = 0 ORDER BY triggerTime ASC")
    suspend fun pendingAlerts(now: Long): List<ReminderAlertEntity>

    @Insert suspend fun insertAlerts(alerts: List<ReminderAlertEntity>)

    @Query("DELETE FROM reminder_alerts WHERE reminderId = :reminderId")
    suspend fun deleteAlertsForReminder(reminderId: Long)

    @Query("UPDATE reminder_alerts SET isTriggered = 1 WHERE id = :id")
    suspend fun markAlertTriggered(id: Long)

    @Query("SELECT * FROM categories ORDER BY isDefault DESC, name ASC")
    fun categories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE id = :id LIMIT 1")
    suspend fun categoryById(id: Long): CategoryEntity?

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun categoryCount(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCategories(categories: List<CategoryEntity>)

    @Insert suspend fun insertCategory(category: CategoryEntity): Long
    @Delete suspend fun deleteCategory(category: CategoryEntity)

    @Query("SELECT * FROM routines ORDER BY createdAt DESC")
    fun routines(): Flow<List<RoutineEntity>>
    @Insert suspend fun insertRoutine(routine: RoutineEntity): Long
    @Update suspend fun updateRoutine(routine: RoutineEntity)
    @Delete suspend fun deleteRoutine(routine: RoutineEntity)

    @Query("SELECT * FROM routine_items WHERE routineId = :routineId ORDER BY sortOrder, minutesFromMidnight")
    fun routineItems(routineId: Long): Flow<List<RoutineItemEntity>>
    @Insert suspend fun insertRoutineItem(item: RoutineItemEntity): Long
    @Delete suspend fun deleteRoutineItem(item: RoutineItemEntity)

    @Query("SELECT * FROM ideas ORDER BY createdAt DESC") fun ideas(): Flow<List<IdeaEntity>>
    @Insert suspend fun insertIdea(item: IdeaEntity): Long
    @Delete suspend fun deleteIdea(item: IdeaEntity)

    @Query("SELECT * FROM plans ORDER BY id DESC") fun plans(): Flow<List<PlanEntity>>
    @Insert suspend fun insertPlan(item: PlanEntity): Long
    @Update suspend fun updatePlan(item: PlanEntity)
    @Delete suspend fun deletePlan(item: PlanEntity)

    @Query("SELECT * FROM goals ORDER BY id DESC") fun goals(): Flow<List<GoalEntity>>
    @Insert suspend fun insertGoal(item: GoalEntity): Long
    @Update suspend fun updateGoal(item: GoalEntity)
    @Delete suspend fun deleteGoal(item: GoalEntity)

    @Query("SELECT * FROM trips ORDER BY startAt ASC") fun trips(): Flow<List<TripEntity>>
    @Insert suspend fun insertTrip(item: TripEntity): Long
    @Delete suspend fun deleteTrip(item: TripEntity)
    @Query("SELECT * FROM trip_places WHERE tripId = :tripId ORDER BY visitAt ASC") fun tripPlaces(tripId: Long): Flow<List<TripPlaceEntity>>
    @Insert suspend fun insertTripPlace(item: TripPlaceEntity): Long
    @Delete suspend fun deleteTripPlace(item: TripPlaceEntity)

    @Query("SELECT * FROM profiles ORDER BY CASE WHEN type = 'ME' THEN 0 ELSE 1 END, name ASC") fun profiles(): Flow<List<ProfileEntity>>
    @Query("SELECT COUNT(*) FROM profiles") suspend fun profileCount(): Int
    @Insert suspend fun insertProfile(item: ProfileEntity): Long
    @Delete suspend fun deleteProfile(item: ProfileEntity)

    @Query("SELECT * FROM custom_sounds ORDER BY createdAt DESC") fun customSounds(): Flow<List<CustomSoundEntity>>
    @Insert suspend fun insertCustomSound(item: CustomSoundEntity): Long
    @Delete suspend fun deleteCustomSound(item: CustomSoundEntity)

    @Query("SELECT * FROM completed_history ORDER BY completedAt DESC") fun completedHistory(): Flow<List<CompletedReminderHistoryEntity>>
    @Insert suspend fun insertCompletedHistory(item: CompletedReminderHistoryEntity): Long
    @Query("DELETE FROM completed_history") suspend fun clearCompletedHistory()
}
