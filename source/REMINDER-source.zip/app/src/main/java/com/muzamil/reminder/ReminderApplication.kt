package com.muzamil.reminder

import android.app.Application
import com.muzamil.reminder.data.ReminderDatabase
import com.muzamil.reminder.data.ReminderRepository
import com.muzamil.reminder.data.SettingsStore
import com.muzamil.reminder.scheduling.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ReminderApplication : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val database by lazy { ReminderDatabase.get(this) }
    val repository by lazy { ReminderRepository(database.appDao()) }
    val settingsStore by lazy { SettingsStore(this) }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannels(this)
        appScope.launch { repository.ensureDefaults() }
    }
}
