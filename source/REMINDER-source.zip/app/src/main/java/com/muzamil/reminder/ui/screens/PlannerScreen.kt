package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.ReminderEntity
import com.muzamil.reminder.ui.MainViewModel
import com.muzamil.reminder.ui.components.ReminderCard
import java.time.*

@Composable
fun PlannerScreen(vm: MainViewModel, onEdit: (Long) -> Unit, onCalendar: () -> Unit) {
    val active by vm.active.collectAsState()
    val settings by vm.settings.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now()
    val list = active.filter { r ->
        val d = Instant.ofEpochMilli(r.triggerAt).atZone(zone).toLocalDate()
        when (tab) {
            0 -> d == today
            1 -> d == today.plusDays(1)
            2 -> !d.isBefore(today) && d.isBefore(today.plusDays(7))
            else -> d.isAfter(today.plusDays(6))
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("Planner", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold); Text("Your reminders in chronological order", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = onCalendar) { Icon(Icons.Outlined.CalendarMonth, "Calendar") }
        }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 16.dp) {
            listOf("Today", "Tomorrow", "This Week", "Upcoming").forEachIndexed { i, label -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) }) }
        }
        if (list.isEmpty()) Box(Modifier.fillMaxSize().padding(24.dp)) { Text("No reminders in this view.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        else LazyColumn(contentPadding = PaddingValues(20.dp, 16.dp, 20.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { reminder -> PlannerCard(vm, reminder, settings.use24Hour, onEdit) }
        }
    }
}

@Composable private fun PlannerCard(vm: MainViewModel, reminder: ReminderEntity, use24h: Boolean, onEdit: (Long) -> Unit) {
    ReminderCard(reminder, use24h, { onEdit(reminder.id) }, { vm.completeReminder(reminder) }, { minutes -> vm.snooze(reminder, minutes) }, { vm.deleteReminder(reminder) }, { vm.duplicate(reminder) })
}
