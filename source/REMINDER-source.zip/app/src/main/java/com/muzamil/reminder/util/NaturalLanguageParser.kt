package com.muzamil.reminder.util

import com.muzamil.reminder.domain.NaturalLanguageResult
import com.muzamil.reminder.domain.ReminderType
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

object NaturalLanguageParser {
    private val timeExpressionRegex = Regex("(?i)\\b(?:at\\s+)?\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)\\b|\\bat\\s+\\d{1,2}:\\d{2}\\b|\\bat\\s+\\d{1,2}\\b")
    private val relativeRegex = Regex("(?i)\\bin\\s+(\\d+)\\s+(minute|minutes|hour|hours|day|days|week|weeks)\\b")
    private val numberUnitRegex = Regex("(?i)\\b(one|two|three|four|five|six|seven|\\d+)\\s+(minute|minutes|hour|hours|day|days|week|weeks|month|months)\\b")
    private val advancePhraseRegex = Regex("(?i)(?:(?:one|two|three|four|five|six|seven|\\d+)\\s+(?:minute|minutes|hour|hours|day|days|week|weeks|month|months)(?:\\s*(?:,|and)\\s*)?)+\\s+before\\b")
    private val monthNames = Month.entries.associateBy { it.name.lowercase(Locale.ENGLISH) }
    private val monthWords = Month.entries.joinToString("|") { it.name.lowercase().replaceFirstChar(Char::uppercase) } + "|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec"
    private val namedDateExpressionRegex = Regex("(?i)\\b(?:\\d{1,2}\\s+)?(?:$monthWords)(?:\\s+\\d{1,2})?(?:,?\\s+\\d{4})?\\b")

    fun parse(input: String, now: ZonedDateTime = ZonedDateTime.now()): NaturalLanguageResult {
        var text = input.trim()
        var date = now.toLocalDate()
        var confidence = 0.50f
        var type = ReminderType.ONE_TIME
        var days = ""
        var explicitDate = false
        var relativeInstant: ZonedDateTime? = null

        if (text.contains("tomorrow", true)) { date = date.plusDays(1); explicitDate = true; confidence += .15f }
        if (text.contains("today", true)) { explicitDate = true; confidence += .08f }

        relativeRegex.find(text)?.let { m ->
            val n = m.groupValues[1].toLong()
            relativeInstant = when (m.groupValues[2].lowercase()) {
                "minute", "minutes" -> now.plusMinutes(n)
                "hour", "hours" -> now.plusHours(n)
                "week", "weeks" -> now.plusWeeks(n)
                else -> now.plusDays(n)
            }
            explicitDate = true; confidence += .18f
        }

        parseNamedDate(text, now.toLocalDate())?.let { parsed -> date = parsed; explicitDate = true; confidence += .14f }

        if (text.contains("every weekday", true) || text.contains("weekdays", true)) { type = ReminderType.WEEKDAYS; confidence += .15f }
        else if (text.contains("every weekend", true) || text.contains("weekends", true)) { type = ReminderType.WEEKENDS; confidence += .15f }
        else if (text.contains("every day", true) || text.contains("daily", true)) { type = ReminderType.DAILY; confidence += .15f }
        else if (text.contains("every week", true) || text.contains("weekly", true)) { type = ReminderType.WEEKLY; confidence += .12f }
        else if (text.contains("every month", true) || text.contains("monthly", true)) { type = ReminderType.MONTHLY; confidence += .12f }
        else if (text.contains("every year", true) || text.contains("yearly", true) || text.contains("birthday", true) || text.contains("anniversary", true)) { type = ReminderType.YEARLY; confidence += .10f }

        DayOfWeek.entries.forEach { d ->
            val token = d.name.lowercase(Locale.ENGLISH).replaceFirstChar(Char::uppercase)
            if (Regex("(?i)\\b$token\\b").containsMatchIn(text)) {
                val delta = (d.value - date.dayOfWeek.value + 7) % 7
                if (!explicitDate) date = date.plusDays(if (delta == 0) 7 else delta.toLong())
                if (Regex("(?i)\\bevery\\s+$token\\b").containsMatchIn(text)) { type = ReminderType.SPECIFIC_DAYS; days = d.value.toString() }
                confidence += .08f
            }
        }

        val time = parseTime(text)
        var hour = time?.first ?: 9
        var minute = time?.second ?: 0
        if (time != null) confidence += .15f

        var trigger = relativeInstant ?: date.atTime(hour, minute).atZone(now.zone)
        if (relativeInstant != null && time != null) trigger = relativeInstant!!.toLocalDate().atTime(hour, minute).atZone(now.zone)
        if (!trigger.isAfter(now)) trigger = nextFutureTrigger(trigger, type, days)

        val beforeIndex = text.indexOf("before", ignoreCase = true)
        val offsets = if (beforeIndex >= 0) {
            numberUnitRegex.findAll(text.substring(0, beforeIndex)).mapNotNull { m ->
                val n = wordNumber(m.groupValues[1]) ?: return@mapNotNull null
                unitToMinutes(n, m.groupValues[2])
            }.distinct().toList()
        } else emptyList()
        if (offsets.isNotEmpty()) confidence += .08f

        val category = inferCategory(text)
        if (category != null) confidence += .04f

        text = text
            .replace(Regex("(?i)^remind me(\\s+about)?"), "")
            .replace(relativeRegex, "")
            .replace(advancePhraseRegex, "")
            .replace(namedDateExpressionRegex, "")
            .replace(Regex("(?i)\\b(today|tomorrow|daily|weekly|monthly|yearly|weekdays|weekends|every weekday|every day|every week|every month|every year)\\b"), "")
            .replace(timeExpressionRegex, "")
            .replace(Regex("(?i)\\b(to|at|on)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '.', ',')
        if (text.isBlank()) text = "Reminder"

        if (!explicitDate && type == ReminderType.YEARLY && (input.contains("birthday", true) || input.contains("anniversary", true))) confidence = confidence.coerceAtMost(.62f)

        val millis = trigger.toInstant().toEpochMilli()
        return NaturalLanguageResult(
            title = text.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() },
            triggerAt = millis,
            type = type,
            daysOfWeekCsv = days,
            alertOffsetsMinutes = offsets,
            suggestedCategoryName = category,
            confidence = confidence.coerceAtMost(0.98f),
            explanation = "Interpreted for ${Instant.ofEpochMilli(millis).atZone(now.zone).format(DateTimeFormatter.ofPattern("EEE, d MMM • h:mm a"))}"
        )
    }

    private fun parseTime(text: String): Pair<Int, Int>? {
        val match = timeExpressionRegex.find(text) ?: return null
        var raw = match.value.lowercase().replace("at", "").trim()
        val isPm = raw.endsWith("pm")
        val isAm = raw.endsWith("am")
        raw = raw.removeSuffix("pm").removeSuffix("am").trim()
        val parts = raw.split(':')
        var hour = parts[0].trim().toIntOrNull() ?: return null
        val minute = parts.getOrNull(1)?.trim()?.toIntOrNull()?.coerceIn(0, 59) ?: 0
        if ((isAm || isPm) && hour !in 1..12) return null
        if (isPm && hour < 12) hour += 12
        if (isAm && hour == 12) hour = 0
        if (!isAm && !isPm && hour !in 0..23) return null
        return hour to minute
    }

    private fun nextFutureTrigger(base: ZonedDateTime, type: ReminderType, daysCsv: String): ZonedDateTime = when (type) {
        ReminderType.DAILY -> base.plusDays(1)
        ReminderType.WEEKDAYS -> generateSequence(base.plusDays(1)) { it.plusDays(1) }.first { it.dayOfWeek !in setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY) }
        ReminderType.WEEKENDS -> generateSequence(base.plusDays(1)) { it.plusDays(1) }.first { it.dayOfWeek in setOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY) }
        ReminderType.WEEKLY -> base.plusWeeks(1)
        ReminderType.MONTHLY -> base.plusMonths(1)
        ReminderType.YEARLY -> base.plusYears(1)
        ReminderType.SPECIFIC_DAYS -> {
            val wanted = daysCsv.split(',').mapNotNull { it.toIntOrNull() }.toSet()
            if (wanted.isEmpty()) base.plusWeeks(1) else generateSequence(base.plusDays(1)) { it.plusDays(1) }.first { it.dayOfWeek.value in wanted }
        }
        else -> base.plusDays(1)
    }

    private fun inferCategory(text: String): String? = when {
        hasWord(text, "meeting") || hasWord(text, "call") -> "Meeting"
        hasWord(text, "birthday") || hasWord(text, "anniversary") -> "Birthday"
        hasWord(text, "bill") || hasWord(text, "rent") || hasWord(text, "payment") || hasWord(text, "fee") -> "Payment"
        hasWord(text, "passport") || hasWord(text, "license") || hasWord(text, "cnic") || hasWord(text, "insurance") -> "Documents"
        hasWord(text, "office") || hasWord(text, "report") || hasWord(text, "deadline") -> "Work"
        hasWord(text, "gym") || hasWord(text, "workout") || hasWord(text, "walk") || hasWord(text, "running") -> "Fitness"
        hasWord(text, "bird") || hasWord(text, "birds") || hasWord(text, "cat") || hasWord(text, "dog") || hasWord(text, "pet") -> "Pets"
        hasWord(text, "flight") || hasWord(text, "hotel") || hasWord(text, "trip") || hasWord(text, "travel") -> "Travel"
        hasWord(text, "child") || hasWord(text, "wife") || hasWord(text, "husband") || hasWord(text, "family") -> "Family"
        hasWord(text, "breakfast") || hasWord(text, "lunch") || hasWord(text, "dinner") || hasWord(text, "water") -> "Food"
        else -> null
    }

    private fun hasWord(text: String, word: String): Boolean = Regex("(?i)\\b${Regex.escape(word)}\\b").containsMatchIn(text)

    private fun unitToMinutes(n: Int, unit: String): Long = when (unit.lowercase()) {
        "minute", "minutes" -> n.toLong()
        "hour", "hours" -> n * 60L
        "day", "days" -> n * 1440L
        "week", "weeks" -> n * 10080L
        "month", "months" -> n * 43200L
        else -> 0L
    }

    private fun wordNumber(value: String): Int? = value.toIntOrNull() ?: when (value.lowercase()) {
        "one" -> 1; "two" -> 2; "three" -> 3; "four" -> 4; "five" -> 5; "six" -> 6; "seven" -> 7; else -> null
    }

    private fun parseNamedDate(text: String, today: LocalDate): LocalDate? {
        val lower = text.lowercase(Locale.ENGLISH)
        for ((name, month) in monthNames) {
            val tokens = listOf(name, name.take(3), if (name == "september") "sept" else "")
            val token = tokens.firstOrNull { it.isNotBlank() && Regex("\\b$it\\b").containsMatchIn(lower) } ?: continue
            val after = Regex("(?i)\\b$token\\s+(\\d{1,2})(?:,?\\s*(\\d{4}))?").find(text)
            val before = Regex("(?i)\\b(\\d{1,2})\\s+$token(?:\\s+(\\d{4}))?").find(text)
            val match = after ?: before ?: continue
            val day = match.groupValues[1].toIntOrNull() ?: continue
            val yearText = match.groupValues.getOrNull(2).orEmpty()
            var year = yearText.toIntOrNull() ?: today.year
            val candidate = runCatching { LocalDate.of(year, month, day) }.getOrNull() ?: continue
            if (yearText.isBlank() && candidate.isBefore(today)) year += 1
            return runCatching { LocalDate.of(year, month, day) }.getOrNull()
        }
        return null
    }
}
