package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.MainViewModel
import com.muzamil.reminder.util.DateTimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompletedScreen(vm: MainViewModel, onBack: () -> Unit) {
    val history by vm.completedHistory.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("Completed") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }, actions = { if (history.isNotEmpty()) TextButton(onClick = { confirmClear = true }) { Text("Clear") } }) }) { padding ->
        if (history.isEmpty()) Box(Modifier.padding(padding).fillMaxSize().padding(24.dp)) { Text("No completed reminder history yet.") }
        else LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(history, key = { it.id }) { h ->
                ListItem(headlineContent = { Text(h.title) }, supportingContent = { Text("Completed ${DateTimeUtils.formatDateTime(h.completedAt)}${h.categoryName?.let { " • $it" } ?: ""}") })
                HorizontalDivider()
            }
        }
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("Clear completed history?") }, text = { Text("This removes the history list. Active reminders are not affected.") }, confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear") } }, dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } })
}
