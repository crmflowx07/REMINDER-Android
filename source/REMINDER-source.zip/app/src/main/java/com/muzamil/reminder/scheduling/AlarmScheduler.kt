package com.muzamil.reminder.scheduling

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.muzamil.reminder.data.ReminderAlertEntity
import com.muzamil.reminder.data.ReminderEntity

class AlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    fun schedule(reminder: ReminderEntity, alert: ReminderAlertEntity) {
        if (alert.triggerTime <= System.currentTimeMillis()) return
        val pi = pending(reminder.id, alert.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alert.triggerTime, pi)
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alert.triggerTime, pi)
        }
    }

    fun cancel(reminderId: Long, alertId: Long) {
        alarmManager.cancel(pending(reminderId, alertId))
    }

    private fun pending(reminderId: Long, alertId: Long): PendingIntent {
        val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
            putExtra("reminderId", reminderId)
            putExtra("alertId", alertId)
        }
        val requestCode = ((reminderId * 37 + alertId) % Int.MAX_VALUE).toInt()
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
