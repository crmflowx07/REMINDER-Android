package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(onBack: () -> Unit) {
    Scaffold(topBar={TopAppBar(title={Text("Help & reliability")},navigationIcon={IconButton(onClick=onBack){Icon(Icons.Outlined.ArrowBack,"Back")}})}){padding->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
            Text("Allow REMINDER to send notifications reliably.",style=MaterialTheme.typography.headlineSmall)
            HelpCard("1. Notifications","Android 13+ requires notification permission. You can manage it from Settings → Notifications.")
            HelpCard("2. Exact alarms","Some Android versions require special exact-alarm access for precise times. REMINDER falls back to an allowed alarm method when exact access is unavailable.")
            HelpCard("3. Battery saver","Aggressive device battery settings can delay alarms. If that happens, review your phone's battery optimization settings for REMINDER.")
            HelpCard("4. Phone restart","REMINDER listens for reboot, timezone and clock changes and reschedules pending local alarms.")
            HelpCard("5. Offline-first","Creating, editing, completing, snoozing and scheduling reminders works without an internet connection.")
        }
    }
}
@Composable private fun HelpCard(title:String,text:String){ ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(4.dp));Text(text,color=MaterialTheme.colorScheme.onSurfaceVariant)}} }
