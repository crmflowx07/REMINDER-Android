package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun MoreScreen(onOpen: (String) -> Unit) {
    val items = listOf(
        Triple("Categories", "Create and organize reminder categories", Icons.Outlined.Category),
        Triple("Family Profiles", "Me, spouse, children, parents, pets and others", Icons.Outlined.People),
        Triple("Ideas", "Capture ideas and optionally turn them into reminders", Icons.Outlined.Lightbulb),
        Triple("Plans", "Simple future plans with target dates and progress", Icons.Outlined.EventNote),
        Triple("Goals", "Track simple goals without project-management clutter", Icons.Outlined.Flag),
        Triple("Travel", "Trips, places and travel preparation", Icons.Outlined.Flight),
        Triple("Completed", "Completed reminder history", Icons.Outlined.TaskAlt),
        Triple("Sounds", "Built-in tones and My Sounds", Icons.Outlined.MusicNote),
        Triple("Settings", "Theme, snooze, vibration, export and reliability", Icons.Outlined.Settings),
        Triple("Help", "Notification and battery reliability guidance", Icons.Outlined.HelpOutline)
    )
    val routes = listOf("categories", "profiles", "ideas", "plans", "goals", "travel", "completed", "sounds", "settings", "help")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 20.dp, 20.dp, 110.dp)) {
        item { Text("More", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold); Text("Everything else, without cluttering your day.", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(16.dp)) }
        items(items.size) { i -> MoreRow(items[i].first, items[i].second, items[i].third) { onOpen(routes[i]) }; if (i < items.lastIndex) HorizontalDivider() }
    }
}

@Composable private fun MoreRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        headlineContent = { Text(title) }, supportingContent = { Text(subtitle) },
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) },
        trailingContent = { IconButton(onClick = onClick) { Icon(Icons.Outlined.ChevronRight, "Open $title") } }
    )
}
