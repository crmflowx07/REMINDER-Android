package com.muzamil.reminder.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore("settings")

data class UserSettings(
    val theme: String = "SYSTEM",
    val defaultSnoozeMinutes: Int = 10,
    val vibration: Boolean = true,
    val defaultSound: String = "classic_bell",
    val defaultReminderBeforeMinutes: Long = 0,
    val weekStartsMonday: Boolean = true,
    val use24Hour: Boolean = false,
    val onboardingDone: Boolean = false
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val theme = stringPreferencesKey("theme")
        val snooze = intPreferencesKey("snooze")
        val vibration = booleanPreferencesKey("vibration")
        val sound = stringPreferencesKey("sound")
        val before = longPreferencesKey("before")
        val weekMonday = booleanPreferencesKey("week_monday")
        val use24h = booleanPreferencesKey("use_24h")
        val onboarding = booleanPreferencesKey("onboarding")
    }

    val settings: Flow<UserSettings> = context.settingsDataStore.data.map { p ->
        UserSettings(
            theme = p[Keys.theme] ?: "SYSTEM",
            defaultSnoozeMinutes = p[Keys.snooze] ?: 10,
            vibration = p[Keys.vibration] ?: true,
            defaultSound = p[Keys.sound] ?: "classic_bell",
            defaultReminderBeforeMinutes = p[Keys.before] ?: 0,
            weekStartsMonday = p[Keys.weekMonday] ?: true,
            use24Hour = p[Keys.use24h] ?: false,
            onboardingDone = p[Keys.onboarding] ?: false
        )
    }

    suspend fun setTheme(v: String) = context.settingsDataStore.edit { it[Keys.theme] = v }
    suspend fun setSnooze(v: Int) = context.settingsDataStore.edit { it[Keys.snooze] = v }
    suspend fun setVibration(v: Boolean) = context.settingsDataStore.edit { it[Keys.vibration] = v }
    suspend fun setDefaultSound(v: String) = context.settingsDataStore.edit { it[Keys.sound] = v }
    suspend fun setDefaultBefore(v: Long) = context.settingsDataStore.edit { it[Keys.before] = v }
    suspend fun setWeekStartsMonday(v: Boolean) = context.settingsDataStore.edit { it[Keys.weekMonday] = v }
    suspend fun setUse24Hour(v: Boolean) = context.settingsDataStore.edit { it[Keys.use24h] = v }
    suspend fun setOnboardingDone(v: Boolean) = context.settingsDataStore.edit { it[Keys.onboarding] = v }
}
