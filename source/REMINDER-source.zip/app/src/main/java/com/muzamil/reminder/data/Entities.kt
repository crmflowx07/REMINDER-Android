package com.muzamil.reminder.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String = "notifications",
    val colorArgb: Long? = null,
    val isDefault: Boolean = false
)

@Entity(tableName = "reminders", indices = [Index("triggerAt"), Index("categoryId"), Index("isCompleted")])
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val triggerAt: Long,
    val timezone: String,
    val type: String = "ONE_TIME",
    val repeatInterval: Int = 1,
    val repeatUnit: String = "DAYS",
    val daysOfWeekCsv: String = "",
    val dayOfMonth: Int? = null,
    val monthOfYear: Int? = null,
    val recurrenceEndAt: Long? = null,
    val categoryId: Long? = null,
    val priority: String = "NORMAL",
    val isCompleted: Boolean = false,
    val isDeleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val soundKey: String = "classic_bell",
    val customSoundUri: String? = null,
    val vibrationEnabled: Boolean = true,
    val snoozeDurationMinutes: Int = 10,
    val location: String? = null,
    val meetingEndAt: Long? = null,
    val meetingLink: String? = null,
    val personCompany: String? = null,
    val ownerProfileId: Long? = null,
    val occurrenceCompletedAt: Long? = null
)

@Entity(
    tableName = "reminder_alerts",
    foreignKeys = [ForeignKey(
        entity = ReminderEntity::class,
        parentColumns = ["id"], childColumns = ["reminderId"],
        onDelete = ForeignKey.CASCADE
    )], indices = [Index("reminderId"), Index("triggerTime")]
)
data class ReminderAlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reminderId: Long,
    val offsetMinutes: Long,
    val triggerTime: Long,
    val isTriggered: Boolean = false,
    val isCompleted: Boolean = false
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String = "repeat",
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "routine_items",
    foreignKeys = [ForeignKey(entity = RoutineEntity::class, parentColumns = ["id"], childColumns = ["routineId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("routineId")]
)
data class RoutineItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routineId: Long,
    val title: String,
    val minutesFromMidnight: Int,
    val categoryId: Long? = null,
    val reminderId: Long? = null,
    val enabled: Boolean = true,
    val sortOrder: Int = 0
)

@Entity(tableName = "ideas")
data class IdeaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "General",
    val createdAt: Long = System.currentTimeMillis(),
    val reminderAt: Long? = null
)

@Entity(tableName = "plans")
data class PlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val goal: String,
    val targetAt: Long? = null,
    val notes: String = "",
    val tasksText: String = "",
    val progress: Int = 0
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetAt: Long? = null,
    val reminderFrequency: String = "NONE",
    val progress: Int = 0
)

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startAt: Long,
    val endAt: Long,
    val notes: String = ""
)

@Entity(
    tableName = "trip_places",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class TripPlaceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tripId: Long,
    val name: String,
    val visitAt: Long? = null,
    val notes: String = ""
)


@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String = "OTHER",
    val birthdayAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_sounds")
data class CustomSoundEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val uri: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "completed_history", indices = [Index("reminderId")])
data class CompletedReminderHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reminderId: Long,
    val title: String,
    val completedAt: Long,
    val originalTriggerAt: Long,
    val categoryName: String? = null
)
