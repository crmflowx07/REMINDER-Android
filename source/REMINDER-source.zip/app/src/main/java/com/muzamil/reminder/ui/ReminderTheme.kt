package com.muzamil.reminder.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF315C57),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4E9E4),
    onPrimaryContainer = Color(0xFF0B211E),
    secondary = Color(0xFF58645F),
    surface = Color(0xFFF8FAF8),
    surfaceVariant = Color(0xFFE7ECE9),
    background = Color(0xFFF8FAF8),
    error = Color(0xFFBA1A1A)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9FD2C8),
    onPrimary = Color(0xFF003731),
    primaryContainer = Color(0xFF174F49),
    onPrimaryContainer = Color(0xFFD4E9E4),
    surface = Color(0xFF111412),
    surfaceVariant = Color(0xFF29302D),
    background = Color(0xFF111412)
)

@Composable
fun ReminderTheme(theme: String = "SYSTEM", content: @Composable () -> Unit) {
    val dark = when (theme) { "DARK" -> true; "LIGHT" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
