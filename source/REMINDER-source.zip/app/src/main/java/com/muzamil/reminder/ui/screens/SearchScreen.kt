package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.MainViewModel
import com.muzamil.reminder.ui.components.ReminderCard
import com.muzamil.reminder.util.DateTimeUtils

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(vm: MainViewModel, onBack: () -> Unit, onEdit: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("All") }
    var priority by remember { mutableStateOf("All") }
    var categoryId by remember { mutableStateOf<Long?>(null) }
    val raw by vm.search(query).collectAsState(initial = emptyList())
    val categories by vm.categories.collectAsState()
    val settings by vm.settings.collectAsState()
    val now = System.currentTimeMillis()
    val filtered = raw.filter { r ->
        val statusOk = when (status) {
            "Today" -> !r.isCompleted && r.triggerAt in DateTimeUtils.startOfToday()..DateTimeUtils.endOfToday()
            "Upcoming" -> !r.isCompleted && r.triggerAt > DateTimeUtils.endOfToday()
            "Overdue" -> !r.isCompleted && r.triggerAt < now
            "Completed" -> r.isCompleted
            else -> true
        }
        val priorityOk = priority == "All" || r.priority == priority.uppercase()
        val categoryOk = categoryId == null || r.categoryId == categoryId
        statusOk && priorityOk && categoryOk
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Search & Filter") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 20.dp)) {
            OutlinedTextField(query, { query = it }, label = { Text("Search title, notes or category") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("All", "Today", "Upcoming", "Overdue", "Completed").forEach { value -> FilterChip(selected = status == value, onClick = { status = value }, label = { Text(value) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterMenu("Priority: $priority", listOf("All", "Normal", "Important", "Urgent")) { priority = it }
                val categoryName = categories.firstOrNull { it.id == categoryId }?.name ?: "All categories"
                FilterMenu(categoryName, listOf("All categories") + categories.map { it.name }) { selected -> categoryId = categories.firstOrNull { it.name == selected }?.id }
            }
            Spacer(Modifier.height(8.dp))
            Text("${filtered.size} results", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
                items(filtered, key = { it.id }) { r ->
                    if (r.isCompleted) {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            ListItem(
                                headlineContent = { Text(r.title) },
                                supportingContent = { Text("Completed • ${DateTimeUtils.formatDateTime(r.occurrenceCompletedAt ?: r.triggerAt, settings.use24Hour)}") },
                                trailingContent = { TextButton(onClick = { vm.deleteReminder(r) }) { Text("Delete") } }
                            )
                        }
                    } else {
                        ReminderCard(r, settings.use24Hour, { onEdit(r.id) }, { vm.completeReminder(r) }, { minutes -> vm.snooze(r, minutes) }, { vm.deleteReminder(r) }, { vm.duplicate(r) })
                    }
                }
            }
        }
    }
}

@Composable private fun FilterMenu(label: String, values: List<String>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(label, maxLines = 1) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            values.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { onSelect(value); open = false }) }
        }
    }
}
