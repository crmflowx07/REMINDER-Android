package com.muzamil.reminder.scheduling

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.muzamil.reminder.ReminderApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val reminderId = intent.getLongExtra("reminderId", -1L)
        val app = context.applicationContext as ReminderApplication
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val reminder = app.repository.reminderById(reminderId) ?: return@launch
                val coordinator = ScheduleCoordinator(context, app.repository)
                when (intent.action) {
                    "SNOOZE" -> {
                        val minutes = intent.getIntExtra("minutes", reminder.snoozeDurationMinutes)
                        val updated = app.repository.snooze(reminder, minutes)
                        app.repository.updateReminder(updated, listOf(0L))
                        coordinator.reschedule(updated)
                    }
                    "COMPLETE" -> {
                        coordinator.cancel(reminder.id)
                        val next = app.repository.completeReminder(reminder)
                        if (next != null) {
                            val offsets = app.repository.alertsForReminder(reminder.id).map { it.offsetMinutes }.ifEmpty { listOf(0L) }
                            app.repository.updateReminder(next, offsets)
                            coordinator.reschedule(next)
                        }
                    }
                    "STOP" -> Unit
                }
                context.getSystemService(NotificationManager::class.java).cancel(reminderId.toInt())
            } finally { pendingResult.finish() }
        }
    }
}
