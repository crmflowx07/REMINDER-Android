package com.muzamil.reminder.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by vm.settings.collectAsState()
    var info by remember { mutableStateOf<Pair<String,String>?>(null) }
    var importResult by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(vm.exportJson()) }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (text != null) vm.importJson(text) { importResult = "$it reminders imported." }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())) {
            SettingsSection("Appearance")
            ChoiceRow("Theme", s.theme, listOf("SYSTEM", "LIGHT", "DARK")) { scope.launch { vm.settingsStore.setTheme(it) } }
            SwitchRow("24-hour time", "Use 24-hour time throughout the app", s.use24Hour) { scope.launch { vm.settingsStore.setUse24Hour(it) } }
            SwitchRow("Week starts Monday", "Planner and calendar preference", s.weekStartsMonday) { scope.launch { vm.settingsStore.setWeekStartsMonday(it) } }

            SettingsSection("Reminder defaults")
            NumberChoiceRow("Default snooze", s.defaultSnoozeMinutes, listOf(5,10,30,60), " min") { scope.launch { vm.settingsStore.setSnooze(it) } }
            SwitchRow("Vibration", "Use vibration by default", s.vibration) { scope.launch { vm.settingsStore.setVibration(it) } }
            NumberChoiceRow("Reminder before", s.defaultReminderBeforeMinutes.toInt(), listOf(0,5,15,60,1440), " min") { scope.launch { vm.settingsStore.setDefaultBefore(it.toLong()) } }

            SettingsSection("Reliability")
            ActionRow("Notification settings", "Allow REMINDER to send notifications reliably") {
                context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
            }
            ActionRow("Exact alarm access", "Android may require special access for precise reminder times") {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) runCatching { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))) }
            }
            ActionRow("Battery optimization", "Open Android battery optimization settings if reminders are delayed") {
                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }

            SettingsSection("Data")
            ActionRow("Load demo data", "Add the supplied sample reminders, routines and example travel data once") { vm.loadDemoData { count -> importResult = if (count == 0) "Demo data already appears to be loaded." else "$count demo reminders added." } }
            ActionRow("Export reminders", "Save a local JSON backup; no account required") { exportLauncher.launch("REMINDER-backup.json") }
            ActionRow("Import reminders", "Import a REMINDER JSON backup") { importLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }
            importResult?.let { Text(it, modifier = Modifier.padding(horizontal=20.dp, vertical=6.dp), color = MaterialTheme.colorScheme.primary) }

            SettingsSection("About")
            ActionRow("Privacy", "Core reminders stay on this device") { info = "Privacy" to "REMINDER is offline-first. Reminder contents are stored locally and are not uploaded by this V1 build. Custom audio is chosen through Android's system picker." }
            ActionRow("Terms", "Simple local-use terms placeholder for store release") { info = "Terms" to "Use REMINDER to manage personal reminders. You remain responsible for critical deadlines and device notification settings. Replace this placeholder with your published legal terms before Play release." }
            ActionRow("About REMINDER", "Version 1.0.0") { info = "REMINDER" to "Remember your life. Plan your time. Never forget what matters." }
            Spacer(Modifier.height(40.dp))
        }
    }
    info?.let { (title, text) -> AlertDialog(onDismissRequest={info=null}, title={Text(title)}, text={Text(text)}, confirmButton={TextButton(onClick={info=null}){Text("OK")}}) }
}

@Composable private fun SettingsSection(text:String){ Text(text, style=MaterialTheme.typography.titleSmall, color=MaterialTheme.colorScheme.primary, modifier=Modifier.padding(start=20.dp,end=20.dp,top=22.dp,bottom=6.dp)) }
@Composable private fun SwitchRow(title:String, subtitle:String, checked:Boolean, onChange:(Boolean)->Unit){ ListItem(headlineContent={Text(title)},supportingContent={Text(subtitle)},trailingContent={Switch(checked,onChange)}) }
@Composable private fun ActionRow(title:String, subtitle:String, onClick:()->Unit){ ListItem(headlineContent={Text(title)},supportingContent={Text(subtitle)},trailingContent={TextButton(onClick=onClick){Text("Open")}}) }

@Composable private fun ChoiceRow(title:String, value:String, values:List<String>, onChange:(String)->Unit){
    var menu by remember{mutableStateOf(false)}
    ListItem(headlineContent={Text(title)},supportingContent={Text(value.lowercase().replaceFirstChar{it.uppercase()})},trailingContent={Box{TextButton(onClick={menu=true}){Text("Change")};DropdownMenu(menu,{menu=false}){values.forEach{v->DropdownMenuItem(text={Text(v.lowercase().replaceFirstChar{it.uppercase()})},onClick={onChange(v);menu=false})}}}})
}
@Composable private fun NumberChoiceRow(title:String, value:Int, values:List<Int>, suffix:String, onChange:(Int)->Unit){
    var menu by remember{mutableStateOf(false)}
    ListItem(headlineContent={Text(title)},supportingContent={Text("$value$suffix")},trailingContent={Box{TextButton(onClick={menu=true}){Text("Change")};DropdownMenu(menu,{menu=false}){values.forEach{v->DropdownMenuItem(text={Text("$v$suffix")},onClick={onChange(v);menu=false})}}}})
}
