package com.muzamil.reminder.domain

enum class ReminderType { ONE_TIME, DAILY, WEEKLY, MONTHLY, YEARLY, CUSTOM, WEEKDAYS, WEEKENDS, SPECIFIC_DAYS }
enum class Priority { NORMAL, IMPORTANT, URGENT }
enum class ReminderStatus { UPCOMING, OVERDUE, COMPLETED }

data class NaturalLanguageResult(
    val title: String,
    val triggerAt: Long?,
    val type: ReminderType = ReminderType.ONE_TIME,
    val repeatInterval: Int = 1,
    val daysOfWeekCsv: String = "",
    val alertOffsetsMinutes: List<Long> = emptyList(),
    val suggestedCategoryName: String? = null,
    val confidence: Float = 0.5f,
    val explanation: String = ""
)

object Defaults {
    val categories = listOf(
        "General" to "notifications",
        "Personal" to "person",
        "Family" to "family_restroom",
        "Work" to "work",
        "Meeting" to "groups",
        "Birthday" to "cake",
        "Payment" to "payments",
        "Documents" to "description",
        "Travel" to "flight",
        "Fitness" to "fitness_center",
        "Food" to "restaurant",
        "Routine" to "repeat",
        "Pets" to "pets",
        "Farm" to "agriculture",
        "Vehicle" to "directions_car",
        "Ideas" to "lightbulb",
        "Goals" to "flag",
        "Plans" to "event_note"
    )

    val soundNames = listOf(
        "Classic Bell", "Gentle Chime", "Morning Bell", "Soft Piano", "Elegant",
        "Digital Alert", "Important Alert", "Bright Chime", "Clock Reminder", "Strong Reminder"
    )
}
