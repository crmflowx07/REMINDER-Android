package com.muzamil.reminder.util

import java.time.*
import java.time.format.DateTimeFormatter

object DateTimeUtils {
    fun startOfToday(): Long = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    fun endOfToday(): Long = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1
    fun formatTime(millis: Long, use24h: Boolean = false): String {
        val pattern = if (use24h) "HH:mm" else "hh:mm a"
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern(pattern))
    }
    fun formatDate(millis: Long): String = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy"))
    fun formatDateTime(millis: Long, use24h: Boolean = false): String = "${formatDate(millis)} • ${formatTime(millis, use24h)}"
    fun greeting(): String = when (LocalTime.now().hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        else -> "Good evening"
    }
}
