package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriesScreen(vm: MainViewModel, onBack: () -> Unit) {
    val categories by vm.categories.collectAsState()
    var add by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("Categories") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }, actions = { IconButton(onClick = { add = true }) { Icon(Icons.Outlined.Add, "Add category") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp)) {
            items(categories, key = { it.id }) { c ->
                ListItem(headlineContent = { Text(c.name) }, supportingContent = { Text(if (c.isDefault) "Default category" else "Custom category") }, leadingContent = { Icon(Icons.Outlined.Label, null) }, trailingContent = { if (!c.isDefault) IconButton(onClick = { vm.deleteCategory(c) }) { Icon(Icons.Outlined.Delete, "Delete") } })
                HorizontalDivider()
            }
        }
    }
    if (add) TextInputDialog("New category", "Category name", { add = false }) { vm.addCategory(it); add = false }
}

@Composable
fun TextInputDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(text, { text = it }, label = { Text(label) }, singleLine = true) }, confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trim()) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
