package com.muzamil.reminder.scheduling

import com.muzamil.reminder.R

data class BuiltInSound(val key: String, val name: String, val rawRes: Int)

object SoundCatalog {
    val builtIns = listOf(
        BuiltInSound("classic_bell", "Classic Bell", R.raw.classic_bell),
        BuiltInSound("gentle_chime", "Gentle Chime", R.raw.gentle_chime),
        BuiltInSound("morning_bell", "Morning Bell", R.raw.morning_bell),
        BuiltInSound("soft_piano", "Soft Piano", R.raw.soft_piano),
        BuiltInSound("elegant", "Elegant", R.raw.elegant),
        BuiltInSound("digital_alert", "Digital Alert", R.raw.digital_alert),
        BuiltInSound("important_alert", "Important Alert", R.raw.important_alert),
        BuiltInSound("bright_chime", "Bright Chime", R.raw.bright_chime),
        BuiltInSound("clock_reminder", "Clock Reminder", R.raw.clock_reminder),
        BuiltInSound("strong_reminder", "Strong Reminder", R.raw.strong_reminder)
    )

    fun rawResFor(key: String): Int = builtIns.firstOrNull { it.key == key }?.rawRes ?: R.raw.classic_bell
}
