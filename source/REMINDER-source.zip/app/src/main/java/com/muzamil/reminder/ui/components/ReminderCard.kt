package com.muzamil.reminder.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.ReminderEntity
import com.muzamil.reminder.util.DateTimeUtils

@Composable
fun ReminderCard(
    reminder: ReminderEntity,
    use24h: Boolean,
    onEdit: () -> Unit,
    onComplete: () -> Unit,
    onSnooze: (Int) -> Unit,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit
) {
    var snoozeOpen by remember { mutableStateOf(false) }
    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(DateTimeUtils.formatTime(reminder.triggerAt, use24h), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Text(reminder.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (reminder.description.isNotBlank()) Text(reminder.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
                if (reminder.priority != "NORMAL") AssistChip(onClick = {}, label = { Text(reminder.priority.lowercase().replaceFirstChar { it.uppercase() }) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Outlined.CalendarToday, null, modifier = Modifier.size(16.dp))
                Text(DateTimeUtils.formatDate(reminder.triggerAt), style = MaterialTheme.typography.labelMedium)
                if (reminder.customSoundUri != null) { Spacer(Modifier.width(4.dp)); Icon(Icons.Outlined.MusicNote, "Custom sound", modifier = Modifier.size(16.dp)) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onComplete) { Icon(Icons.Outlined.Check, null); Spacer(Modifier.width(4.dp)); Text("Complete") }
                TextButton(onClick = { snoozeOpen = true }) { Icon(Icons.Outlined.Snooze, null); Spacer(Modifier.width(4.dp)); Text("Snooze") }
                Box {
                    var expanded by remember { mutableStateOf(false) }
                    IconButton(onClick = { expanded = true }) { Icon(Icons.Outlined.MoreVert, "More actions") }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        DropdownMenuItem(text = { Text("Edit / Reschedule") }, leadingIcon = { Icon(Icons.Outlined.Edit, null) }, onClick = { expanded = false; onEdit() })
                        DropdownMenuItem(text = { Text("Duplicate") }, leadingIcon = { Icon(Icons.Outlined.ContentCopy, null) }, onClick = { expanded = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("Delete") }, leadingIcon = { Icon(Icons.Outlined.Delete, null) }, onClick = { expanded = false; onDelete() })
                    }
                }
            }
        }
    }
    if (snoozeOpen) SnoozeDialog(defaultMinutes = reminder.snoozeDurationMinutes, onDismiss = { snoozeOpen = false }) { minutes -> snoozeOpen = false; onSnooze(minutes) }
}

@Composable private fun SnoozeDialog(defaultMinutes: Int, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    var custom by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Snooze reminder") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 30, 60).distinct().forEach { minutes ->
                    OutlinedButton(onClick = { onSelect(minutes) }, modifier = Modifier.fillMaxWidth()) { Text(if (minutes == 60) "1 hour" else "$minutes minutes") }
                }
                if (defaultMinutes !in listOf(5,10,30,60)) OutlinedButton(onClick = { onSelect(defaultMinutes) }, modifier = Modifier.fillMaxWidth()) { Text("Default: $defaultMinutes minutes") }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(custom, { custom = it.filter(Char::isDigit).take(4) }, label = { Text("Custom minutes") }, modifier = Modifier.weight(1f), singleLine = true)
                    Button(enabled = (custom.toIntOrNull() ?: 0) > 0, onClick = { onSelect(custom.toInt()) }) { Text("Snooze") }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
