package com.muzamil.reminder.scheduling

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.muzamil.reminder.ReminderApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val reminderId = intent.getLongExtra("reminderId", -1L)
        val alertId = intent.getLongExtra("alertId", -1L)
        val app = context.applicationContext as ReminderApplication
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val reminder = app.repository.reminderById(reminderId)
                if (reminder != null && !reminder.isDeleted && !reminder.isCompleted) {
                    if (alertId > 0) app.repository.markAlertTriggered(alertId)
                    NotificationHelper.show(context, reminder, alertId)
                }
            } finally { pendingResult.finish() }
        }
    }
}
