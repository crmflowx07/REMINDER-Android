package com.muzamil.reminder.scheduling

import android.content.Context
import com.muzamil.reminder.data.ReminderEntity
import com.muzamil.reminder.data.ReminderRepository

class ScheduleCoordinator(private val context: Context, private val repository: ReminderRepository) {
    private val scheduler = AlarmScheduler(context)

    suspend fun reschedule(reminder: ReminderEntity) {
        repository.alertsForReminder(reminder.id).forEach { scheduler.cancel(reminder.id, it.id) }
        repository.alertsForReminder(reminder.id).forEach { scheduler.schedule(reminder, it) }
    }

    suspend fun scheduleAll() {
        val pending = repository.pendingAlerts()
        pending.groupBy { it.reminderId }.forEach { (reminderId, alerts) ->
            val reminder = repository.reminderById(reminderId) ?: return@forEach
            if (!reminder.isDeleted && !reminder.isCompleted) alerts.forEach { scheduler.schedule(reminder, it) }
        }
    }

    suspend fun cancel(reminderId: Long) {
        repository.alertsForReminder(reminderId).forEach { scheduler.cancel(reminderId, it.id) }
    }
}
