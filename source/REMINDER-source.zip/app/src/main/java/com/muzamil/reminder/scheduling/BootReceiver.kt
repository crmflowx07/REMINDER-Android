package com.muzamil.reminder.scheduling

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.muzamil.reminder.ReminderApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val supported = setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_MY_PACKAGE_REPLACED)
        if (intent.action !in supported) return
        val pendingResult = goAsync()
        val app = context.applicationContext as ReminderApplication
        CoroutineScope(Dispatchers.IO).launch {
            try { ScheduleCoordinator(context, app.repository).scheduleAll() }
            finally { pendingResult.finish() }
        }
    }
}
