package com.muzamil.reminder.ui.screens

import android.content.Intent
import android.media.MediaPlayer
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.CustomSoundEntity
import com.muzamil.reminder.scheduling.SoundCatalog
import com.muzamil.reminder.ui.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val customs by vm.customSounds.collectAsState()
    val settings by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) { onDispose { player?.release() } }

    fun play(mp: MediaPlayer?) {
        player?.release(); player = mp
        runCatching { player?.start() }
    }
    fun displayName(uri: android.net.Uri): String {
        var name = "Custom sound"
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name }
        return name
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.addCustomSound(CustomSoundEntity(displayName = displayName(uri), uri = uri.toString()))
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Reminder Sounds") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item { Text("Built-in", style = MaterialTheme.typography.titleMedium); Text("Original tones bundled with the app.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(SoundCatalog.builtIns, key = { it.key }) { sound ->
                ListItem(
                    headlineContent = { Text(sound.name) },
                    leadingContent = { Icon(Icons.Outlined.MusicNote, null) },
                    trailingContent = {
                        Row {
                            IconButton(onClick = { play(MediaPlayer.create(context, sound.rawRes)) }) { Icon(Icons.Outlined.PlayArrow, "Preview") }
                            RadioButton(selected = settings.defaultSound == sound.key, onClick = { scope.launch { vm.settingsStore.setDefaultSound(sound.key) } })
                        }
                    }
                )
            }
            item { HorizontalDivider(Modifier.padding(vertical = 10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text("My Sounds", style = MaterialTheme.typography.titleMedium); Text("Choose audio with Android's system picker.", style = MaterialTheme.typography.bodySmall) }; FilledTonalButton(onClick = { picker.launch(arrayOf("audio/*")) }) { Icon(Icons.Outlined.Add, null); Text("Add from Phone") } } }
            if (customs.isEmpty()) item { Text("No custom sounds added.", modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(customs, key = { it.id }) { sound ->
                ListItem(headlineContent = { Text(sound.displayName) }, supportingContent = { Text("My Sounds") }, leadingContent = { Icon(Icons.Outlined.AudioFile, null) }, trailingContent = { Row { IconButton(onClick = { play(MediaPlayer.create(context, android.net.Uri.parse(sound.uri))) }) { Icon(Icons.Outlined.PlayArrow, "Preview") }; IconButton(onClick = { vm.deleteCustomSound(sound) }) { Icon(Icons.Outlined.Delete, "Remove") } } })
            }
        }
    }
}
