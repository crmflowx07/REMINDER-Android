package com.muzamil.reminder.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.RoutineEntity
import com.muzamil.reminder.data.RoutineItemEntity
import com.muzamil.reminder.ui.MainViewModel
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@Composable
fun RoutinesScreen(vm: MainViewModel) {
    val routines by vm.routines.collectAsState()
    var addRoutine by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Routines", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                Text("Morning, fitness, work, pets and any routine you create.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(onClick = { addRoutine = true }) { Icon(Icons.Outlined.Add, null); Text("Routine") }
        }
        Spacer(Modifier.height(16.dp))
        if (routines.isEmpty()) {
            ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(24.dp)) { Text("No routines yet.", style = MaterialTheme.typography.titleMedium); Text("Create a routine, then add timed items such as Wake up, Breakfast or Workout.") } }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 110.dp)) {
                items(routines, key = { it.id }) { routine -> RoutineCard(vm, routine) }
            }
        }
    }
    if (addRoutine) TextInputDialog("New routine", "Routine name", onDismiss = { addRoutine = false }) { vm.addRoutine(it); addRoutine = false }
}

@Composable private fun RoutineCard(vm: MainViewModel, routine: RoutineEntity) {
    val items by vm.repository.routineItems(routine.id).collectAsState(initial = emptyList())
    var expanded by remember { mutableStateOf(false) }
    var addItem by remember { mutableStateOf(false) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Repeat, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(routine.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text("${items.size} items", style = MaterialTheme.typography.bodySmall) }
                IconButton(onClick = { expanded = !expanded }) { Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, "Expand") }
            }
            if (expanded) {
                if (items.isEmpty()) Text("No items yet.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 10.dp))
                items.forEach { item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatMinutes(item.minutesFromMidnight), modifier = Modifier.width(78.dp), color = MaterialTheme.colorScheme.primary)
                        Text(item.title, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.deleteRoutineItem(item) }) { Icon(Icons.Outlined.Delete, "Delete item") }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { addItem = true }) { Text("+ Add item") }
                    TextButton(onClick = { vm.deleteRoutine(routine) }) { Text("Delete routine") }
                }
            }
        }
    }
    if (addItem) RoutineItemDialog(onDismiss = { addItem = false }) { title, mins -> vm.addRoutineItem(RoutineItemEntity(routineId = routine.id, title = title, minutesFromMidnight = mins, sortOrder = items.size)); addItem = false }
}

@Composable private fun RoutineItemDialog(onDismiss: () -> Unit, onSave: (String, Int) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var mins by remember { mutableIntStateOf(8 * 60) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add routine item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") })
                OutlinedButton(onClick = { TimePickerDialog(context, { _, h, m -> mins = h * 60 + m }, mins / 60, mins % 60, false).show() }) { Icon(Icons.Outlined.Schedule, null); Spacer(Modifier.width(6.dp)); Text(formatMinutes(mins)) }
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { onSave(title.trim(), mins) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun formatMinutes(total: Int): String = LocalTime.of(total / 60, total % 60).format(DateTimeFormatter.ofPattern("hh:mm a"))
