package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.MainViewModel
import com.muzamil.reminder.ui.components.ReminderCard
import com.muzamil.reminder.util.DateTimeUtils

@Composable
fun HomeScreen(vm: MainViewModel, onAdd: () -> Unit, onEdit: (Long) -> Unit, onSearch: () -> Unit) {
    val today by vm.today.collectAsState()
    val upcoming by vm.upcoming.collectAsState()
    val overdue by vm.overdue.collectAsState()
    val settings by vm.settings.collectAsState()
    var deleteTarget by remember { mutableStateOf<com.muzamil.reminder.data.ReminderEntity?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp, 18.dp, 20.dp, 110.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("REMINDER", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(DateTimeUtils.greeting(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = onSearch) { Icon(Icons.Outlined.Search, "Search") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("Today", today.size, Modifier.weight(1f))
                SummaryCard("Upcoming", upcoming.size, Modifier.weight(1f))
                SummaryCard("Overdue", overdue.size, Modifier.weight(1f), overdue.isNotEmpty())
            }
        }
        item {
            Spacer(Modifier.height(2.dp))
            Text("TODAY", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
        }
        if (today.isEmpty()) {
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("You're all caught up.", style = MaterialTheme.typography.titleMedium)
                        Text("No reminders today.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = onAdd) { Text("+ Add Reminder") }
                    }
                }
            }
        } else {
            items(today, key = { it.id }) { reminder ->
                ReminderCard(
                    reminder = reminder, use24h = settings.use24Hour,
                    onEdit = { onEdit(reminder.id) }, onComplete = { vm.completeReminder(reminder) },
                    onSnooze = { minutes -> vm.snooze(reminder, minutes) },
                    onDelete = { deleteTarget = reminder }, onDuplicate = { vm.duplicate(reminder) }
                )
            }
        }
        if (overdue.isNotEmpty()) {
            item { Text("OVERDUE", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
            items(overdue.take(5), key = { "overdue-${it.id}" }) { reminder ->
                ReminderCard(
                    reminder, settings.use24Hour, { onEdit(reminder.id) }, { vm.completeReminder(reminder) },
                    { minutes -> vm.snooze(reminder, minutes) }, { deleteTarget = reminder }, { vm.duplicate(reminder) }
                )
            }
        }
    }

    deleteTarget?.let { reminder ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete reminder?") },
            text = { Text("${reminder.title} will be removed.") },
            confirmButton = { TextButton(onClick = { vm.deleteReminder(reminder); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable private fun SummaryCard(label: String, count: Int, modifier: Modifier, warning: Boolean = false) {
    Surface(modifier, shape = MaterialTheme.shapes.large, color = if (warning) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(count.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("reminders", style = MaterialTheme.typography.bodySmall)
        }
    }
}
