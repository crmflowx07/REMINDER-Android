package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pages = listOf(
        Triple("Never forget what matters.", "Reliable reminders that stay simple.", Icons.Outlined.NotificationsActive),
        Triple("One place for everyday life.", "Work, family, payments, routines, travel and important dates.", Icons.Outlined.EventAvailable),
        Triple("Create a reminder in seconds.", "Add a title, date and time. Advanced options stay out of the way until you need them.", Icons.Outlined.AddAlarm)
    )
    var page by remember { mutableIntStateOf(0) }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(104.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(pages[page].third, null, modifier = Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary) }
            }
            Spacer(Modifier.height(28.dp))
            Text("REMINDER", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(pages[page].first, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text(pages[page].second, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pages.indices.forEach { index ->
                    Surface(color = if (index == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.small, modifier = Modifier.size(if (index == page) 24.dp else 8.dp, 8.dp)) {}
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { if (page < pages.lastIndex) page++ else onFinish() }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text(if (page == pages.lastIndex) "Get Started" else "Continue")
            }
            Spacer(Modifier.height(8.dp))
            Text("Notifications are requested only so your reminders can arrive on time.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}
