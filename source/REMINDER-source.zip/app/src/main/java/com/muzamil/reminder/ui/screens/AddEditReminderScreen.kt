package com.muzamil.reminder.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.ReminderEntity
import com.muzamil.reminder.scheduling.SoundCatalog
import com.muzamil.reminder.ui.MainViewModel
import com.muzamil.reminder.util.DateTimeUtils
import com.muzamil.reminder.util.NaturalLanguageParser
import java.time.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditReminderScreen(vm: MainViewModel, reminderId: Long, onDone: () -> Unit) {
    val context = LocalContext.current
    val categories by vm.categories.collectAsState()
    val customSounds by vm.customSounds.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val settings by vm.settings.collectAsState()
    val zone = ZoneId.systemDefault()

    var title by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var triggerAt by remember { mutableLongStateOf(System.currentTimeMillis() + 60 * 60 * 1000L) }
    var repeat by remember { mutableStateOf("ONE_TIME") }
    var interval by remember { mutableIntStateOf(1) }
    var repeatUnit by remember { mutableStateOf("DAYS") }
    var daysCsv by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf<Long?>(null) }
    var ownerProfileId by remember { mutableStateOf<Long?>(null) }
    var priority by remember { mutableStateOf("NORMAL") }
    var soundKey by remember { mutableStateOf(settings.defaultSound) }
    var customSoundUri by remember { mutableStateOf<String?>(null) }
    var vibration by remember { mutableStateOf(settings.vibration) }
    var snoozeMinutes by remember { mutableIntStateOf(settings.defaultSnoozeMinutes) }
    var location by remember { mutableStateOf("") }
    var meetingLink by remember { mutableStateOf("") }
    var personCompany by remember { mutableStateOf("") }
    var meetingEndAt by remember { mutableStateOf<Long?>(null) }
    var advanced by remember { mutableStateOf(false) }
    var quickText by remember { mutableStateOf("") }
    var parsedMessage by remember { mutableStateOf<String?>(null) }
    var alertOffsets by remember { mutableStateOf(if (settings.defaultReminderBeforeMinutes > 0) setOf(settings.defaultReminderBeforeMinutes) else emptySet()) }
    var loaded by remember { mutableStateOf(reminderId == 0L) }

    LaunchedEffect(reminderId) {
        if (reminderId != 0L) {
            vm.reminder(reminderId)?.let { r ->
                title = r.title; notes = r.description; triggerAt = r.triggerAt; repeat = r.type
                interval = r.repeatInterval; repeatUnit = r.repeatUnit; daysCsv = r.daysOfWeekCsv; categoryId = r.categoryId
                priority = r.priority; ownerProfileId = r.ownerProfileId; soundKey = r.soundKey; customSoundUri = r.customSoundUri
                vibration = r.vibrationEnabled; snoozeMinutes = r.snoozeDurationMinutes
                location = r.location.orEmpty(); meetingLink = r.meetingLink.orEmpty(); personCompany = r.personCompany.orEmpty(); meetingEndAt = r.meetingEndAt
                alertOffsets = vm.alertOffsets(r.id).filter { it > 0 }.toSet(); loaded = true
            }
        }
    }

    if (!loaded) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return }

    val dateTime = Instant.ofEpochMilli(triggerAt).atZone(zone)
    val selectedCategory = categories.firstOrNull { it.id == categoryId }
    val isMeeting = selectedCategory?.name == "Meeting"
    val invalidPast = triggerAt <= System.currentTimeMillis()

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (reminderId == 0L) "Add Reminder" else "Edit Reminder") },
            navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.Outlined.Close, "Close") } },
            actions = {
                TextButton(enabled = title.isNotBlank() && !invalidPast, onClick = {
                    val reminder = ReminderEntity(
                        id = reminderId, title = title.trim(), description = notes.trim(), triggerAt = triggerAt,
                        timezone = zone.id, type = repeat, repeatInterval = interval.coerceAtLeast(1), repeatUnit = repeatUnit, daysOfWeekCsv = daysCsv,
                        categoryId = categoryId, priority = priority, ownerProfileId = ownerProfileId, soundKey = soundKey, customSoundUri = customSoundUri,
                        vibrationEnabled = vibration, snoozeDurationMinutes = snoozeMinutes, location = location.ifBlank { null },
                        meetingLink = meetingLink.ifBlank { null }, personCompany = personCompany.ifBlank { null }, meetingEndAt = meetingEndAt
                    )
                    vm.saveReminder(reminder, alertOffsets.toList()) { onDone() }
                }) { Text("Save", fontWeight = FontWeight.Bold) }
            }
        )
    }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, placeholder = { Text("Pay electricity bill") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        val d = Instant.ofEpochMilli(triggerAt).atZone(zone)
                        DatePickerDialog(context, { _, y, m, day ->
                            triggerAt = LocalDate.of(y, m + 1, day).atTime(Instant.ofEpochMilli(triggerAt).atZone(zone).toLocalTime()).atZone(zone).toInstant().toEpochMilli()
                        }, d.year, d.monthValue - 1, d.dayOfMonth).show()
                    }, modifier = Modifier.weight(1f)
                ) { Icon(Icons.Outlined.CalendarMonth, null); Spacer(Modifier.width(6.dp)); Text(DateTimeUtils.formatDate(triggerAt)) }
                OutlinedButton(
                    onClick = {
                        val d = Instant.ofEpochMilli(triggerAt).atZone(zone)
                        TimePickerDialog(context, { _, h, min ->
                            triggerAt = Instant.ofEpochMilli(triggerAt).atZone(zone).toLocalDate().atTime(h, min).atZone(zone).toInstant().toEpochMilli()
                        }, d.hour, d.minute, settings.use24Hour).show()
                    }, modifier = Modifier.weight(1f)
                ) { Icon(Icons.Outlined.Schedule, null); Spacer(Modifier.width(6.dp)); Text(DateTimeUtils.formatTime(triggerAt, settings.use24Hour)) }
            }
            if (invalidPast) Text("Choose a future date and time.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Smart quick entry", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = quickText, onValueChange = { quickText = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Remind me tomorrow at 8 AM to feed my birds") }, maxLines = 3
                    )
                    Button(onClick = {
                        val parsed = NaturalLanguageParser.parse(quickText)
                        title = parsed.title; parsed.triggerAt?.let { triggerAt = it }; repeat = parsed.type.name; daysCsv = parsed.daysOfWeekCsv
                        if (parsed.alertOffsetsMinutes.isNotEmpty()) alertOffsets = parsed.alertOffsetsMinutes.toSet()
                        parsed.suggestedCategoryName?.let { suggested ->
                            categories.firstOrNull { it.name == suggested }?.let { c -> categoryId = c.id; soundKey = defaultSoundForCategory(c.name); customSoundUri = null }
                        }
                        parsedMessage = "${parsed.explanation} • ${"%.0f".format(parsed.confidence * 100)}% confidence. Review before saving."
                    }, enabled = quickText.isNotBlank()) { Text("Interpret") }
                    parsedMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }

            TextButton(onClick = { advanced = !advanced }) {
                Icon(if (advanced) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null)
                Spacer(Modifier.width(6.dp)); Text(if (advanced) "Hide Options" else "More Options")
            }

            if (advanced) {
                SectionTitle("Repeat")
                SingleChoiceChips(
                    options = listOf("ONE_TIME" to "Doesn't repeat", "DAILY" to "Daily", "WEEKDAYS" to "Weekdays", "WEEKENDS" to "Weekends", "WEEKLY" to "Weekly", "MONTHLY" to "Monthly", "YEARLY" to "Yearly", "SPECIFIC_DAYS" to "Specific days", "CUSTOM" to "Custom"),
                    selected = repeat, onSelect = { repeat = it }
                )
                if (repeat == "CUSTOM") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = interval.toString(), onValueChange = { interval = it.toIntOrNull()?.coerceIn(1, 10000) ?: 1 }, label = { Text("Every") }, modifier = Modifier.weight(1f), singleLine = true)
                        var unitMenu by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { unitMenu = true }) { Text(repeatUnit.lowercase().replaceFirstChar { it.uppercase() }) }
                            DropdownMenu(expanded = unitMenu, onDismissRequest = { unitMenu = false }) {
                                listOf("MINUTES", "HOURS", "DAYS", "WEEKS", "MONTHS").forEach { u -> DropdownMenuItem(text = { Text(u.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { repeatUnit = u; unitMenu = false }) }
                            }
                        }
                    }
                }
                if (repeat == "SPECIFIC_DAYS") {
                    val selectedDays = daysCsv.split(',').mapNotNull { it.toIntOrNull() }.toSet()
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu", 5 to "Fri", 6 to "Sat", 7 to "Sun").forEach { (value, label) ->
                            FilterChip(selected = value in selectedDays, onClick = {
                                val updated = if (value in selectedDays) selectedDays - value else selectedDays + value
                                daysCsv = updated.sorted().joinToString(",")
                            }, label = { Text(label) })
                        }
                    }
                }

                SectionTitle("Remind Before")
                val presets = listOf(
                    259200L to "6 months", 129600L to "3 months", 43200L to "1 month", 20160L to "2 weeks", 10080L to "1 week", 4320L to "3 days", 1440L to "1 day",
                    720L to "12 hours", 360L to "6 hours", 180L to "3 hours", 60L to "1 hour", 30L to "30 min", 15L to "15 min", 10L to "10 min", 5L to "5 min"
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { (minutes, label) ->
                        FilterChip(selected = minutes in alertOffsets, onClick = { alertOffsets = if (minutes in alertOffsets) alertOffsets - minutes else alertOffsets + minutes }, label = { Text(label) })
                    }
                }
                CustomBeforeField(onAdd = { alertOffsets = alertOffsets + it })
                if (alertOffsets.isNotEmpty()) Text("Selected: ${alertOffsets.sortedDescending().joinToString { beforeLabel(it) }}", style = MaterialTheme.typography.bodySmall)

                SectionTitle("Category")
                var categoryMenu by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = categoryMenu, onExpandedChange = { categoryMenu = it }) {
                    OutlinedTextField(
                        value = selectedCategory?.name ?: "No category", onValueChange = {}, readOnly = true,
                        label = { Text("Category") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(categoryMenu) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                        DropdownMenuItem(text = { Text("No category") }, onClick = { categoryId = null; categoryMenu = false })
                        categories.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { categoryId = c.id; soundKey = defaultSoundForCategory(c.name); customSoundUri = null; categoryMenu = false }) }
                    }
                }

                SectionTitle("Profile")
                var profileMenu by remember { mutableStateOf(false) }
                val profileName = profiles.firstOrNull { it.id == ownerProfileId }?.name ?: "No profile"
                Box {
                    OutlinedButton(onClick = { profileMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(profileName) }
                    DropdownMenu(expanded = profileMenu, onDismissRequest = { profileMenu = false }) {
                        DropdownMenuItem(text = { Text("No profile") }, onClick = { ownerProfileId = null; profileMenu = false })
                        profiles.forEach { p -> DropdownMenuItem(text = { Text("${p.name} • ${p.type.lowercase()}") }, onClick = { ownerProfileId = p.id; profileMenu = false }) }
                    }
                }

                if (isMeeting) {
                    SectionTitle("Meeting details")
                    OutlinedTextField(location, { location = it }, label = { Text("Location") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(meetingLink, { meetingLink = it }, label = { Text("Meeting link") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(personCompany, { personCompany = it }, label = { Text("Person / company") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = {
                        val base = meetingEndAt ?: (triggerAt + 60 * 60 * 1000L)
                        val d = Instant.ofEpochMilli(base).atZone(zone)
                        TimePickerDialog(context, { _, h, min ->
                            val startDate = Instant.ofEpochMilli(triggerAt).atZone(zone).toLocalDate()
                            var candidate = startDate.atTime(h, min).atZone(zone).toInstant().toEpochMilli()
                            if (candidate <= triggerAt) candidate += 24 * 60 * 60 * 1000L
                            meetingEndAt = candidate
                        }, d.hour, d.minute, settings.use24Hour).show()
                    }) { Text(meetingEndAt?.let { "Ends ${DateTimeUtils.formatDateTime(it, settings.use24Hour)}" } ?: "Add optional end time") }
                }

                SectionTitle("Sound")
                var soundMenu by remember { mutableStateOf(false) }
                val soundLabel = customSoundUri?.let { uri -> customSounds.firstOrNull { it.uri == uri }?.displayName } ?: SoundCatalog.builtIns.firstOrNull { it.key == soundKey }?.name ?: "Classic Bell"
                ExposedDropdownMenuBox(expanded = soundMenu, onExpandedChange = { soundMenu = it }) {
                    OutlinedTextField(soundLabel, {}, readOnly = true, label = { Text("Reminder sound") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(soundMenu) }, modifier = Modifier.fillMaxWidth().menuAnchor())
                    ExposedDropdownMenu(expanded = soundMenu, onDismissRequest = { soundMenu = false }) {
                        SoundCatalog.builtIns.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { soundKey = s.key; customSoundUri = null; soundMenu = false }) }
                        customSounds.forEach { s -> DropdownMenuItem(text = { Text("My Sounds • ${s.displayName}") }, onClick = { customSoundUri = s.uri; soundMenu = false }) }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Vibration"); Text("Vibrate with the reminder", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Switch(checked = vibration, onCheckedChange = { vibration = it })
                }

                SectionTitle("Priority")
                SingleChoiceChips(listOf("NORMAL" to "Normal", "IMPORTANT" to "Important", "URGENT" to "Urgent"), priority) { priority = it }

                OutlinedTextField(value = snoozeMinutes.toString(), onValueChange = { snoozeMinutes = it.toIntOrNull()?.coerceIn(1, 1440) ?: 10 }, label = { Text("Default snooze (minutes)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), maxLines = 6)
            }
            Spacer(Modifier.height(90.dp))
        }
    }
}

@Composable private fun SectionTitle(text: String) = Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun SingleChoiceChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) -> FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label) }) }
    }
}

@Composable private fun CustomBeforeField(onAdd: (Long) -> Unit) {
    var value by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("minutes") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value, { value = it.filter(Char::isDigit).take(5) }, label = { Text("Custom") }, modifier = Modifier.weight(1f), singleLine = true)
        var menu by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { menu = true }) { Text(unit) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                listOf("minutes", "hours", "days").forEach { u -> DropdownMenuItem(text = { Text(u) }, onClick = { unit = u; menu = false }) }
            }
        }
        IconButton(onClick = {
            val n = value.toLongOrNull() ?: return@IconButton
            val mins = when (unit) { "hours" -> n * 60; "days" -> n * 1440; else -> n }
            if (mins > 0) { onAdd(mins); value = "" }
        }) { Icon(Icons.Outlined.Add, "Add custom advance alert") }
    }
}

private fun beforeLabel(minutes: Long): String = when {
    minutes % 43200L == 0L -> "${minutes / 43200}mo"
    minutes % 10080L == 0L -> "${minutes / 10080}w"
    minutes % 1440L == 0L -> "${minutes / 1440}d"
    minutes % 60L == 0L -> "${minutes / 60}h"
    else -> "${minutes}m"
}

private fun defaultSoundForCategory(category: String): String = when (category) {
    "Meeting", "Work" -> "digital_alert"
    "Birthday" -> "bright_chime"
    "Payment", "Documents" -> "important_alert"
    "Family" -> "gentle_chime"
    "Fitness" -> "morning_bell"
    "Travel" -> "elegant"
    "Vehicle" -> "clock_reminder"
    else -> "classic_bell"
}
