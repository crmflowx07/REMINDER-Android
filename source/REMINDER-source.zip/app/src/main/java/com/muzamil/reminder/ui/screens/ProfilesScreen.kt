package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.ProfileEntity
import com.muzamil.reminder.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen(vm: MainViewModel, onBack: () -> Unit) {
    val profiles by vm.profiles.collectAsState()
    var add by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("Family Profiles") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }, actions = { IconButton(onClick = { add = true }) { Icon(Icons.Outlined.PersonAdd, "Add profile") } }) }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp)) {
            item { Text("Optional profiles make family reminders easier. Core reminders still work without them.", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(10.dp)) }
            items(profiles, key = { it.id }) { p ->
                ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text(p.type.lowercase().replace('_',' ').replaceFirstChar { it.uppercase() }) }, leadingContent = { Icon(if (p.type == "PET") Icons.Outlined.Pets else Icons.Outlined.Person, null) }, trailingContent = { if (p.type != "ME") IconButton(onClick = { vm.deleteProfile(p) }) { Icon(Icons.Outlined.Delete, "Delete") } })
                HorizontalDivider()
            }
        }
    }
    if (add) ProfileDialog(onDismiss = { add=false }) { name,type -> vm.addProfile(ProfileEntity(name=name,type=type)); add=false }
}

@Composable private fun ProfileDialog(onDismiss:()->Unit,onSave:(String,String)->Unit){
    var name by remember{mutableStateOf("")}; var type by remember{mutableStateOf("CHILD")}; var menu by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Add profile")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(name,{name=it},label={Text("Name")});Box{OutlinedButton(onClick={menu=true}){Text(type.lowercase().replaceFirstChar{it.uppercase()})};DropdownMenu(menu,{menu=false}){listOf("WIFE","HUSBAND","CHILD","PARENT","PET","OTHER").forEach{v->DropdownMenuItem(text={Text(v.lowercase().replaceFirstChar{it.uppercase()})},onClick={type=v;menu=false})}}}}},confirmButton={TextButton(enabled=name.isNotBlank(),onClick={onSave(name.trim(),type)}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
