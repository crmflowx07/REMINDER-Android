package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.MainViewModel
import com.muzamil.reminder.ui.components.ReminderCard
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(vm: MainViewModel, onBack: () -> Unit, onEdit: (Long) -> Unit) {
    var selected by remember { mutableStateOf(LocalDate.now()) }
    val reminders by remember(selected) { vm.repository.remindersForDay(selected) }.collectAsState(initial = emptyList())
    val settings by vm.settings.collectAsState()
    Scaffold(topBar = { TopAppBar(title = { Text("Calendar") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Text(selected.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
            FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (-3L..10L).forEach { delta ->
                    val d = LocalDate.now().plusDays(delta)
                    FilterChip(selected = d == selected, onClick = { selected = d }, label = { Column { Text(d.dayOfWeek.name.take(3)); Text(d.dayOfMonth.toString()) } })
                }
            }
            HorizontalDivider(Modifier.padding(top = 12.dp))
            if (reminders.isEmpty()) Text("No reminders on this date.", modifier = Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            else LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(reminders, key = { it.id }) { r -> ReminderCard(r, settings.use24Hour, { onEdit(r.id) }, { vm.completeReminder(r) }, { minutes -> vm.snooze(r, minutes) }, { vm.deleteReminder(r) }, { vm.duplicate(r) }) }
            }
        }
    }
}
