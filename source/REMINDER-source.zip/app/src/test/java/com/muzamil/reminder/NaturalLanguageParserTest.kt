package com.muzamil.reminder

import com.muzamil.reminder.domain.ReminderType
import com.muzamil.reminder.util.NaturalLanguageParser
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class NaturalLanguageParserTest {
    private val fixedNow = ZonedDateTime.of(2026, 9, 24, 12, 0, 0, 0, ZoneId.of("Asia/Karachi"))

    @Test fun parsesTomorrowTime() {
        val r = NaturalLanguageParser.parse("Remind me tomorrow at 8 AM to feed my birds", fixedNow)
        assertTrue(r.title.contains("feed my birds", ignoreCase = true))
        assertNotNull(r.triggerAt)
        assertEquals(ReminderType.ONE_TIME, r.type)
    }

    @Test fun parsesWeekdays() {
        val r = NaturalLanguageParser.parse("Remind me every weekday at 8:30 AM to leave for office", fixedNow)
        assertEquals(ReminderType.WEEKDAYS, r.type)
        assertTrue(r.title.contains("leave for office", ignoreCase = true))
    }

    @Test fun birthdayDefaultsYearly() {
        val r = NaturalLanguageParser.parse("Remind me about wife's birthday at 7 PM", fixedNow)
        assertEquals(ReminderType.YEARLY, r.type)
    }
}
