package com.muzamil.reminder

import org.junit.Assert.assertEquals
import org.junit.Test

class ReminderDataRulesTest {
    @Test fun multipleAdvanceAlertsAreDistinct() {
        val offsets = (listOf(43200L, 10080L, 1440L, 120L, 0L, 0L)).distinct()
        assertEquals(listOf(43200L, 10080L, 1440L, 120L, 0L), offsets)
    }
}
