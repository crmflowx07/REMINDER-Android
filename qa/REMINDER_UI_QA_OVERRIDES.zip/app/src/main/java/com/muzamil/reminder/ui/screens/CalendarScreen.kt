package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.*
import com.muzamil.reminder.ui.components.ReminderCard
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(vm: MainViewModel, onBack: () -> Unit, onEdit: (Long) -> Unit) {
    var selected by remember { mutableStateOf(LocalDate.now()) }
    val reminders by remember(selected) { vm.repository.remindersForDay(selected) }.collectAsState(initial = emptyList())
    val settings by vm.settings.collectAsState()

    FigmaPageScaffold(title = "Calendar", onBack = onBack) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            FigmaCard(Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        selected.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        (-3L..10L).forEach { delta ->
                            val d = LocalDate.now().plusDays(delta)
                            FilterChip(
                                selected = d == selected,
                                onClick = { selected = d },
                                label = { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(d.dayOfWeek.name.take(3)); Text(d.dayOfMonth.toString()) } }
                            )
                        }
                    }
                }
            }

            if (reminders.isEmpty()) {
                Box(Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    FigmaEmptyState("No reminders", "Your schedule is clear for this date.", Icons.Outlined.CalendarMonth)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(reminders, key = { it.id }) { r ->
                        ReminderCard(r, settings.use24Hour, { onEdit(r.id) }, { vm.completeReminder(r) }, { minutes -> vm.snooze(r, minutes) }, { vm.deleteReminder(r) }, { vm.duplicate(r) })
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}
