package com.muzamil.reminder.ui.screens

import android.content.Intent
import android.media.MediaPlayer
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.data.CustomSoundEntity
import com.muzamil.reminder.scheduling.SoundCatalog
import com.muzamil.reminder.ui.*
import kotlinx.coroutines.launch

@Composable
fun SoundsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val customs by vm.customSounds.collectAsState()
    val settings by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) { onDispose { player?.release() } }

    fun play(mp: MediaPlayer?) {
        player?.release(); player = mp
        runCatching { player?.start() }
    }
    fun displayName(uri: android.net.Uri): String {
        var name = "Custom sound"
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: name }
        return name
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.addCustomSound(CustomSoundEntity(displayName = displayName(uri), uri = uri.toString()))
        }
    }

    FigmaPageScaffold(title = "Reminder Sounds", onBack = onBack) { padding ->
        LazyColumn(
            Modifier.padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                FigmaSectionHeader("Built-in")
                Text("Original tones bundled with the app.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(SoundCatalog.builtIns, key = { it.key }) { sound ->
                FigmaRowCard(sound.name, "Built-in reminder tone", Icons.Outlined.MusicNote, FigmaPurpleSoft) {
                    IconButton(onClick = { play(MediaPlayer.create(context, sound.rawRes)) }) { Icon(Icons.Outlined.PlayArrow, "Preview", tint = FigmaPurple) }
                    RadioButton(selected = settings.defaultSound == sound.key, onClick = { scope.launch { vm.settingsStore.setDefaultSound(sound.key) } })
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        FigmaSectionHeader("My Sounds", customs.size)
                        Text("Choose audio with Android's system picker.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    FilledTonalButton(onClick = { picker.launch(arrayOf("audio/*")) }) { Icon(Icons.Outlined.Add, null); Spacer(Modifier.width(4.dp)); Text("Add") }
                }
            }
            if (customs.isEmpty()) item { FigmaEmptyState("No custom sounds", "Add a sound from your phone and use it for reminders.", Icons.Outlined.AudioFile) }
            items(customs, key = { it.id }) { sound ->
                FigmaRowCard(sound.displayName, "My Sounds", Icons.Outlined.AudioFile, FigmaBlue) {
                    IconButton(onClick = { play(MediaPlayer.create(context, android.net.Uri.parse(sound.uri))) }) { Icon(Icons.Outlined.PlayArrow, "Preview", tint = FigmaPurple) }
                    IconButton(onClick = { vm.deleteCustomSound(sound) }) { Icon(Icons.Outlined.Delete, "Remove", tint = FigmaSecondary) }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
