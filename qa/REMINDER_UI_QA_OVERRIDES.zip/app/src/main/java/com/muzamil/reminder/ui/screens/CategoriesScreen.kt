package com.muzamil.reminder.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.muzamil.reminder.ui.*

@Composable
fun CategoriesScreen(vm: MainViewModel, onBack: () -> Unit) {
    val categories by vm.categories.collectAsState()
    var add by remember { mutableStateOf(false) }

    FigmaPageScaffold(
        title = "Categories",
        onBack = onBack,
        actions = {
            IconButton(onClick = { add = true }) {
                Surface(color = FigmaPurpleSoft, shape = MaterialTheme.shapes.medium) {
                    Box(Modifier.size(36.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                        Icon(Icons.Outlined.Add, "Add category", tint = FigmaPurple)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (categories.isEmpty()) item { FigmaEmptyState("No categories", "Create a category to keep reminders organized.", Icons.Outlined.Category) }
            items(categories, key = { it.id }) { c ->
                FigmaRowCard(
                    title = c.name,
                    subtitle = if (c.isDefault) "Default category" else "Custom category",
                    icon = Icons.Outlined.Label,
                    tint = if (c.isDefault) FigmaPurpleSoft else FigmaPink
                ) {
                    if (!c.isDefault) IconButton(onClick = { vm.deleteCategory(c) }) { Icon(Icons.Outlined.Delete, "Delete", tint = FigmaSecondary) }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (add) TextInputDialog("New category", "Category name", { add = false }) { name ->
        vm.addCategory(name)
        add = false
    }
}

@Composable
private fun TextInputDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
